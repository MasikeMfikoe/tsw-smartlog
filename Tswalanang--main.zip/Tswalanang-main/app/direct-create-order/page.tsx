"use client"

import CreateOrder from "@/components/CreateOrder"

export default function DirectCreateOrderPage() {
  return <CreateOrder />
}
