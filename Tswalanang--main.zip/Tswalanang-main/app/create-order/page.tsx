"use client"

import CreateOrder from "@/components/CreateOrder"

export default function CreateOrderPage() {
  return <CreateOrder />
}
