"use client"

// This component is no longer needed as navigation is handled by AppLayout
// Keeping it as an empty component to avoid breaking imports
export function Navigation() {
  return null
}
